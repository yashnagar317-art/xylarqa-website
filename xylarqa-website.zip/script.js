
// Replace with your API Key & Channel ID
const API_KEY = 'YOUR_YOUTUBE_API_KEY';
const CHANNEL_ID = 'YOUR_CHANNEL_ID';
const MAX_RESULTS = 12;

const videoGrid = document.getElementById('video-grid');

fetch(`https://www.googleapis.com/youtube/v3/search?key=${API_KEY}&channelId=${CHANNEL_ID}&part=snippet,id&order=date&maxResults=${MAX_RESULTS}`)
  .then(response => response.json())
  .then(data => {
    const videos = data.items;
    videos.forEach(video => {
      if(video.id.kind === "youtube#video"){
        const videoId = video.id.videoId;
        const iframe = document.createElement('iframe');
        iframe.src = `https://www.youtube.com/embed/${videoId}`;
        iframe.allow = "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture";
        iframe.allowFullscreen = true;
        videoGrid.appendChild(iframe);
      }
    });
  })
  .catch(err => console.error("Error fetching videos: ", err));
